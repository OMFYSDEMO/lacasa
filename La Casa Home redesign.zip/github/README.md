# Lacasa Homestay — Website

Website for **Lacasa Homestay**, a family-run, women-led homestay in Sreevaraham, Thiruvananthapuram (Trivandrum), Kerala — a short walk from Sree Padmanabhaswamy Temple.

Live site: https://lacasahome.in

## Design direction

Calm, resort-style and minimal, with a warm "coming home" feeling — family cooking, slow mornings and everyone around one table.

- **Palette:** sand `#f5f0e7`, linen `#ebe3d5`, earth brown `#3a3128`, bronze `#8a6a3e`, cocoa `#5b4a36`
- **Type:** Cormorant Garamond (light headings, italics for emphasis) + Jost (body, spaced uppercase labels)
- **Layout:** full-screen photo hero, generous whitespace, centred section intros, alternating image/text rows

## Page structure

1. **Hero:** full-screen house photo, centred logo, nav, "Book your stay"
2. **Booking bar:** arrival, departure, room and guests → opens a pre-filled WhatsApp enquiry
3. **Our home:** short intro to the family and the house
4. **A day at Lacasa:** Morning / Midday / Evening (coffee, kitchen, family table)
5. **Kitchen quote:** full-width kitchen image with a hospitality line
6. **Rooms:** Standard Double Room and Deluxe Family Room
7. **Ratings:** Google, Booking.com, Kerala Tourism
8. **Neighbourhood:** nearby temples, markets, beaches and the airport, plus a map link
9. **Enquire and footer:** WhatsApp, phone, address

## Booking

There's no online payment. The booking bar builds a WhatsApp message to `+91 97469 98998` containing the selected dates, room and guest count. The hosts reply personally.

## Project structure

```
/
├── index.html          # Main page
├── images/             # Photography (see IMAGES.md)
├── README.md
├── CONTENT.md          # All site copy, editable in one place
└── IMAGES.md           # Image list and usage
```

## Running locally

It's a static site, so there's no build step:

```bash
git clone https://github.com/<your-org>/lacasa-homestay.git
cd lacasa-homestay
npx serve .   # or open index.html directly
```

## Deployment

Works on any static host — GitHub Pages, Netlify, Vercel or cPanel.
For GitHub Pages: **Settings → Pages → Deploy from branch → `main` / root**, then add `lacasahome.in` as the custom domain.

## Before going live

- [ ] Confirm room prices (currently from ₹2,300 and ₹3,600 per night)
- [ ] Confirm the WhatsApp / phone number
- [ ] Confirm whether home-cooked meals are offered (the copy mentions them)
- [ ] Update ratings and review counts
- [ ] Compress images (WebP, under 300 KB each)
- [ ] Add a favicon, meta description and Open Graph image

## Contact

Lacasa Homestay
TC 40/1072, Cheppil Lane, Mukkolakal, Manacaud – Muttathara Rd,
Sreevaraham P.O., Thiruvananthapuram 695009, Kerala
+91 97469 98998
