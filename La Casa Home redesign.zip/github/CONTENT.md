# Site Content

All copy used on the site. Edit this file first, then update `index.html`.

## Hero
- **Label:** Welcome to Lacasa
- **Headline:** Where the kitchen is warm *and the door is open*
- **Sub:** A family-run home in Sreevaraham, a short walk from Sree Padmanabhaswamy Temple.
- **Button:** Book your stay

## Our home
- **Label:** Our home
- **Headline:** Not a hotel. A family house in the old heart of Thiruvananthapuram, *with a room kept ready for you.*
- **Body:** Lacasa is family-run and women-led. There's filter coffee in the morning, the smell of something cooking by noon, and someone at home to tell you which temple gate to use.

## A day at Lacasa
| Time | Title | Body |
|---|---|---|
| Morning | Filter coffee and slow mornings | Start the day the Kerala way — a steel tumbler of coffee, the newspaper, and the temple bells drifting over the rooftops. |
| Midday | A kitchen that feels like family | Spices, coconut and curry leaves — the kitchen is the heart of the house. Ask the hosts about home-style meals during your stay. |
| Evening | Everyone around one table | Back from the temple or the beach, families gather in the lounge, swap stories and settle in like they never left home. |

## Kitchen quote
- **Label:** From our kitchen
- **Quote:** "Sit down, have something to eat. You've had a long journey."

## Rooms
- **Intro:** Air-conditioned, Wi-Fi throughout, attached bath, fresh linen. Simple, spotless and quiet.

| Room | For | Description | Features | From / night |
|---|---|---|---|---|
| Standard Double Room | Two | Bright and calm, with garden views — ideal for couples and solo travellers. | Double bed · AC · Attached bath · Wi-Fi | ₹2,300 |
| Deluxe Family Room | Families | Two large beds, a dining table and a sitting corner — room for the whole family. | Two beds · Dining area · AC · TV | ₹3,600 |

## Ratings
- 4.7 — Google (72 reviews)
- 9.4 — Booking.com (147 reviews)
- Gold — Kerala Tourism homestay

## Neighbourhood
- **Headline:** Temple bells, *market lanes, the sea nearby*
- **Body:** A residential lane in Sreevaraham — central for the temple, the old fort and the coast. The hosts are always happy to point you to the best local tea shop.

| Place | Note |
|---|---|
| Sree Padmanabhaswamy Temple | Walking distance |
| Attukal Bhagavathy Temple | Temple |
| East Fort | Heritage |
| Chalai Market | Food & spices |
| Napier Museum | Culture |
| Shanghumukham Beach | Sunsets |
| Kovalam | Day trip |
| Trivandrum Airport | Easy access |

## Enquire
- **Label:** Come home
- **Headline:** We'll keep the *light on for you*
- **Body:** Message the hosts with your dates — they reply personally with availability and the best rate.
- **Buttons:** WhatsApp the hosts · +91 97469 98998

## WhatsApp message template
```
Hello Lacasa, I'd like to enquire about a stay.
Room: {room}
Guests: {guests}
Arrival: {checkIn}
Departure: {checkOut}
```
