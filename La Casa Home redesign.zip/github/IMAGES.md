# Images

Put all photos in `/images`. Use WebP or JPG, around 2000px on the long edge for full-bleed shots and 1400px for the rest, ideally under 300 KB each.

| File | Used in | Notes |
|---|---|---|
| `hero-exterior.jpg` | Hero (full screen) | House exterior at dusk |
| `lounge.jpg` | A day at Lacasa · Morning | Lounge / sitting area |
| `kitchen.jpg` | A day at Lacasa · Midday, Kitchen quote banner | Home kitchen |
| `family-room.jpg` | A day at Lacasa · Evening, Deluxe Family Room card | Family room with dining table |
| `standard-room.jpg` | Standard Double Room card | Double room |

## Guidelines
- Natural light, warm tones, no heavy filters
- Show signs of life: coffee cups, fresh flowers, a set table
- Always write descriptive `alt` text, for accessibility and SEO
- Lazy-load everything below the hero (`loading="lazy"`)
